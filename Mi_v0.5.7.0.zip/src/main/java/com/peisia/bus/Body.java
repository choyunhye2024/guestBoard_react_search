
package com.peisia.bus;

import java.util.List;

public class Body {

	public Integer totalCount;
	public List<Item> items;
	public Integer pageNo;
	public Integer numOfRows;

}
